# Project 1: Introducing the Lab Environment
This directory contains the source code for [Project 1](https://class.ee.washington.edu/474/peckol/assignments/lab1/lab1Summer17.pdf)

A Makefile has been provided within each subdirectory to run the necessary gcc commands to compile the source files into binary executables. In order compile all source files within a subdirectory, navigate to that subdirectory and run:
```
make
```

## Subdirectory Catalog:
questions/ - source code for Project1a
apps/ - source code for Applications 1-3
