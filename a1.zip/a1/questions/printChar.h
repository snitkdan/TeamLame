/*
  @param delay1
	Delay between each character
  @param toPrint
	Character to be displayed
  @effects
	Displays toPrint with delay delay1

*/
void printChar(unsigned long *delay1, char toPrint);

